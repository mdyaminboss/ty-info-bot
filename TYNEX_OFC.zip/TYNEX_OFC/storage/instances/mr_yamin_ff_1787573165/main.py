import os
import telebot

# আপনার টেলিগ্রাম বটের টোকেন এখানে বসান (অথবা সরাসরি স্ট্রিং হিসেবে দিতে পারেন)
TOKEN = "8902395736:AAEv-wNNitsdZZd2noWosTE9dBMlMqQt9Zo"

# যদি টোকেন এনভায়রনমেন্ট ভেরিয়েবল থেকে নিতে চান অথবা সরাসরি পেস্ট করতে চান
# TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    user_name = message.from_user.first_name
    bot.reply_to(message, f"হ্যালো {user_name}! 👋\nআপনার NE HOST প্যানেল থেকে বট সফলভাবে চলছে! 🚀")

@bot.message_handler(func=lambda message: True)
def echo_all(message):
    bot.reply_to(message, f"আপনি লিখেছেন: {message.text}")

if __name__ == "__main__":
    print("Bot is starting...")
    bot.infinity_polling()